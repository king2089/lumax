const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for updates (in production, use a database)
const updates = {
  '1.1.0': {
    version: '1.1.0',
    buildNumber: '101',
    releaseDate: new Date().toISOString(),
    features: [
      'Enhanced Gen 1 AI features',
      'Improved live streaming quality',
      'New content creation tools',
      'Performance optimizations',
      'Bug fixes and stability improvements',
      'Strip Club 18+ enhancements',
      'Auto-update improvements'
    ],
    isRequired: false,
    downloadSize: 45.2 * 1024 * 1024, // 45.2 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen1-1.1.0.zip',
    changelog: [
      '🚀 New Gen 1 AI assistant with enhanced capabilities',
      '📺 Improved 4K/8K live streaming with HDR support',
      '🎨 Advanced content creation tools with AI assistance',
      '⚡ Performance improvements and faster loading times',
      '🐛 Fixed various bugs and improved stability',
      '🎯 Enhanced user experience with smoother animations',
      '🔥 Strip Club 18+ new features and improvements',
      '🔄 Auto-update system enhancements'
    ],
    minVersion: '1.0.0',
    maxVersion: '1.0.9',
    updateType: 'minor',
    checksum: 'sha256:abc123def456ghi789',
    isHotUpdate: false,
  },
  '1.2.0': {
    version: '1.2.0',
    buildNumber: '102',
    releaseDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    features: [
      'Advanced AI-powered content recommendations',
      'Real-time collaboration features',
      'Enhanced security and privacy controls',
      'New social features and community tools',
      'Improved accessibility features',
      'Strip Club 18+ advanced features',
      'Gen 2 preview features'
    ],
    isRequired: false,
    downloadSize: 52.8 * 1024 * 1024, // 52.8 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen1-1.2.0.zip',
    changelog: [
      '🤖 AI-powered content recommendations',
      '👥 Real-time collaboration tools',
      '🔒 Enhanced security and privacy',
      '🌐 New social and community features',
      '♿ Improved accessibility support',
      '🔥 Strip Club 18+ advanced features',
      '🚀 Gen 2 preview features unlocked'
    ],
    minVersion: '1.1.0',
    maxVersion: '1.1.9',
    updateType: 'minor',
    checksum: 'sha256:def456ghi789jkl012',
    isHotUpdate: false,
  },
  '2.0.0': {
    version: '2.0.0',
    buildNumber: '200',
    releaseDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    features: [
      '🎮 Luma Game Engine - Full 3D gaming platform',
      '🎯 Advanced AI with Gen 2 capabilities',
      '🌐 Metaverse integration and virtual worlds',
      '🎨 Real-time 3D content creation tools',
      '🎪 Interactive live events and concerts',
      '🤖 AI-powered game development',
      '🎲 Built-in game marketplace',
      '🎭 Advanced avatar customization',
      '🌍 Cross-platform gaming',
      '🎪 Virtual strip club and adult entertainment',
      '🎮 Multiplayer gaming experiences',
      '🎨 3D modeling and animation tools'
    ],
    isRequired: false,
    downloadSize: 150.5 * 1024 * 1024, // 150.5 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen2-2.0.0.zip',
    changelog: [
      '🎮 Luma Game Engine - Complete 3D gaming platform',
      '🎯 Gen 2 AI with advanced reasoning and creativity',
      '🌐 Metaverse integration with virtual worlds',
      '🎨 Real-time 3D content creation and editing',
      '🎪 Interactive live events with 3D avatars',
      '🤖 AI-powered game development tools',
      '🎲 Built-in game marketplace with monetization',
      '🎭 Advanced avatar customization with 3D models',
      '🌍 Cross-platform gaming across devices',
      '🎪 Virtual strip club with 3D adult content',
      '🎮 Multiplayer gaming with real-time physics',
      '🎨 Professional 3D modeling and animation suite',
      '🚀 Performance optimizations for next-gen hardware',
      '🔒 Enhanced security for virtual transactions',
      '🌐 Global CDN for faster content delivery'
    ],
    minVersion: '1.2.0',
    maxVersion: '1.9.9',
    updateType: 'major',
    checksum: 'sha256:gen2abc123def456',
    isHotUpdate: false,
  }
};

// Update history storage
const updateHistory = new Map();

// Helper function to compare versions
function compareVersions(version1, version2) {
  const v1Parts = version1.split('.').map(Number);
  const v2Parts = version2.split('.').map(Number);

  for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
    const v1 = v1Parts[i] || 0;
    const v2 = v2Parts[i] || 0;
    
    if (v1 > v2) return 1;
    if (v1 < v2) return -1;
  }
  
  return 0;
}

// Routes

// Check for updates
app.post('/v1/updates/check', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, appId, channel } = req.body;
    
    console.log(`Update check request from ${deviceId} (${platform}) - current version: ${currentVersion}`);
    
    // Find the latest available update
    let latestUpdate = null;
    for (const [version, update] of Object.entries(updates)) {
      if (compareVersions(version, currentVersion) > 0) {
        if (!latestUpdate || compareVersions(version, latestUpdate.version) > 0) {
          latestUpdate = update;
        }
      }
    }
    
    if (latestUpdate) {
      console.log(`Update available: ${latestUpdate.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: latestUpdate
      });
    } else {
      console.log('No updates available');
      res.json({
        hasUpdate: false,
        message: 'No updates available'
      });
    }
  } catch (error) {
    console.error('Error checking for updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Check for Strip Club specific updates
app.post('/v1/updates/strip-club', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, feature } = req.body;
    
    console.log(`Strip Club update check from ${deviceId} - feature: ${feature}`);
    
    // Check if there's a Strip Club specific update
    const stripClubUpdate = updates['1.1.0']; // Use the latest update for Strip Club features
    
    if (stripClubUpdate && compareVersions(stripClubUpdate.version, currentVersion) > 0) {
      // Add Strip Club specific features
      const enhancedUpdate = {
        ...stripClubUpdate,
        features: [
          ...stripClubUpdate.features,
          'Enhanced adult content filtering',
          'Improved age verification',
          'New nightlife features',
          'Advanced privacy controls'
        ],
        changelog: [
          ...stripClubUpdate.changelog,
          '🔥 Strip Club 18+ enhanced features',
          '🔞 Improved adult content management',
          '🎭 New nightlife entertainment features'
        ]
      };
      
      console.log(`Strip Club update available: ${enhancedUpdate.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: enhancedUpdate
      });
    } else {
      console.log('No Strip Club updates available');
      res.json({
        hasUpdate: false,
        message: 'No Strip Club updates available'
      });
    }
  } catch (error) {
    console.error('Error checking Strip Club updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Check for Gen 2 specific updates
app.post('/v1/updates/gen2', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, feature } = req.body;
    
    console.log(`Gen 2 update check from ${deviceId} - feature: ${feature}`);
    
    // Check if there's a Gen 2 update available
    const gen2Update = updates['2.0.0'];
    
    if (gen2Update && compareVersions(gen2Update.version, currentVersion) > 0) {
      console.log(`Gen 2 update available: ${gen2Update.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: gen2Update
      });
    } else {
      console.log('No Gen 2 updates available');
      res.json({
        hasUpdate: false,
        message: 'No Gen 2 updates available'
      });
    }
  } catch (error) {
    console.error('Error checking Gen 2 updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Report update status
app.post('/v1/updates/report', (req, res) => {
  try {
    const { updateId, status, error, deviceId, timestamp } = req.body;
    
    console.log(`Update status report from ${deviceId}: ${updateId} - ${status}`);
    
    // Store update history
    if (!updateHistory.has(deviceId)) {
      updateHistory.set(deviceId, []);
    }
    
    updateHistory.get(deviceId).push({
      updateId,
      status,
      error,
      timestamp,
      deviceId
    });
    
    res.json({
      success: true,
      message: 'Status reported successfully'
    });
  } catch (error) {
    console.error('Error reporting update status:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Get update history
app.get('/v1/updates/history', (req, res) => {
  try {
    const { deviceId } = req.query;
    
    if (deviceId && updateHistory.has(deviceId)) {
      res.json({
        updates: updateHistory.get(deviceId)
      });
    } else {
      res.json({
        updates: []
      });
    }
  } catch (error) {
    console.error('Error fetching update history:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Simulate update download
app.get('/v1/updates/download/:version', (req, res) => {
  try {
    const { version } = req.params;
    const update = updates[version];
    
    if (!update) {
      return res.status(404).json({
        error: 'Update not found',
        message: `Update version ${version} not found`
      });
    }
    
    console.log(`Download request for version ${version}`);
    
    // Simulate download by sending update info
    res.json({
      downloadUrl: update.downloadUrl,
      size: update.downloadSize,
      checksum: update.checksum
    });
  } catch (error) {
    console.error('Error handling download request:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Health check
app.get('/v1/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    updates: Object.keys(updates)
  });
});

// For Vercel deployment
if (process.env.VERCEL) {
  // Export for Vercel serverless functions
  module.exports = app;
} else {
  // Local development
  app.listen(PORT, () => {
    console.log(`🚀 Luma Update Server running on port ${PORT}`);
    console.log(`📱 Available updates: ${Object.keys(updates).join(', ')}`);
    console.log(`🔗 Health check: http://localhost:${PORT}/v1/health`);
  });
} 