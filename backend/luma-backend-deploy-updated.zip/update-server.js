const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors({
  origin: true, // Allow all origins in development
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Device-ID', 'X-App-Version', 'X-Platform', 'X-App-ID', 'X-Channel']
}));
app.use(express.json());

// In-memory storage for updates (in production, use a database)
const updates = {
  '1.1.0': {
    version: '1.1.0',
    buildNumber: '101',
    releaseDate: new Date('2025-07-01').toISOString(),
    features: [
      'Enhanced Gen 1 AI features',
      'Improved live streaming quality',
      'New content creation tools',
      'Performance optimizations',
      'Bug fixes and stability improvements',
      'Strip Club 18+ enhancements',
      'Auto-update improvements'
    ],
    isRequired: false,
    downloadSize: 45.2 * 1024 * 1024, // 45.2 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen1-1.1.0.zip',
    changelog: [
      '🚀 New Gen 1 AI assistant with enhanced capabilities',
      '📺 Improved 4K/8K live streaming with HDR support',
      '🎨 Advanced content creation tools with AI assistance',
      '⚡ Performance improvements and faster loading times',
      '🐛 Fixed various bugs and improved stability',
      '🎯 Enhanced user experience with smoother animations',
      '🔥 Strip Club 18+ new features and improvements',
      '🔄 Auto-update system enhancements'
    ],
    minVersion: '1.0.0',
    maxVersion: '1.0.9',
    updateType: 'minor',
    checksum: 'sha256:abc123def456ghi789',
    isHotUpdate: false,
  },
  '1.2.0': {
    version: '1.2.0',
    buildNumber: '102',
    releaseDate: new Date('2025-10-01').toISOString(),
    features: [
      'Advanced AI-powered content recommendations',
      'Real-time collaboration features',
      'Enhanced security and privacy controls',
      'New social features and community tools',
      'Improved accessibility features',
      'Strip Club 18+ advanced features',
      'Gen 2 preview features'
    ],
    isRequired: false,
    downloadSize: 52.8 * 1024 * 1024, // 52.8 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen1-1.2.0.zip',
    changelog: [
      '🤖 AI-powered content recommendations',
      '👥 Real-time collaboration tools',
      '🔒 Enhanced security and privacy',
      '🌐 New social and community features',
      '♿ Improved accessibility support',
      '🔥 Strip Club 18+ advanced features',
      '🚀 Gen 2 preview features unlocked'
    ],
    minVersion: '1.1.0',
    maxVersion: '1.1.9',
    updateType: 'minor',
    checksum: 'sha256:def456ghi789jkl012',
    isHotUpdate: false,
  },
  '2.0.0': {
    version: '2.0.0',
    buildNumber: '200',
    releaseDate: new Date('2026-04-01').toISOString(),
    features: [
      '🎮 Luma Game Engine - Full 3D gaming platform',
      '🎯 Advanced AI with Gen 2 capabilities',
      '🌐 Metaverse integration and virtual worlds',
      '🎨 Real-time 3D content creation tools',
      '🎪 Interactive live events and concerts',
      '🤖 AI-powered game development',
      '🎲 Built-in game marketplace',
      '🎭 Advanced avatar customization',
      '🌍 Cross-platform gaming',
      '🎪 Virtual strip club and adult entertainment',
      '🎮 Multiplayer gaming experiences',
      '🎨 3D modeling and animation tools'
    ],
    isRequired: false,
    downloadSize: 150.5 * 1024 * 1024, // 150.5 MB
    downloadUrl: 'https://luma-updates.com/downloads/luma-gen2-2.0.0.zip',
    changelog: [
      '🎮 Luma Game Engine - Complete 3D gaming platform',
      '🎯 Gen 2 AI with advanced reasoning and creativity',
      '🌐 Metaverse integration with virtual worlds',
      '🎨 Real-time 3D content creation and editing',
      '🎪 Interactive live events with 3D avatars',
      '🤖 AI-powered game development tools',
      '🎲 Built-in game marketplace with monetization',
      '🎭 Advanced avatar customization with 3D models',
      '🌍 Cross-platform gaming across devices',
      '🎪 Virtual strip club with 3D adult content',
      '🎮 Multiplayer gaming with real-time physics',
      '🎨 Professional 3D modeling and animation suite',
      '🚀 Performance optimizations for next-gen hardware',
      '🔒 Enhanced security for virtual transactions',
      '🌐 Global CDN for faster content delivery'
    ],
    minVersion: '1.2.0',
    maxVersion: '1.9.9',
    updateType: 'major',
    checksum: 'sha256:gen2abc123def456',
    isHotUpdate: false,
  }
};

// In-memory storage for pre-registrations
let preRegistrations = [];
let stats = {
  totalRegistrations: 15420,
  earlyAccessCount: 0,
  betaAccessCount: 0,
  lastUpdated: new Date().toISOString()
};

// Update history storage
const updateHistory = new Map();

// Helper function to compare versions
function compareVersions(version1, version2) {
  const v1Parts = version1.split('.').map(Number);
  const v2Parts = version2.split('.').map(Number);

  for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
    const v1 = v1Parts[i] || 0;
    const v2 = v2Parts[i] || 0;
    
    if (v1 > v2) return 1;
    if (v1 < v2) return -1;
  }
  
  return 0;
}

// Routes

// Check for updates
app.post('/v1/updates/check', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, appId, channel } = req.body;
    
    console.log(`Update check request from ${deviceId} (${platform}) - current version: ${currentVersion}`);
    
    // Find the latest available update
    let latestUpdate = null;
    for (const [version, update] of Object.entries(updates)) {
      if (compareVersions(version, currentVersion) > 0) {
        if (!latestUpdate || compareVersions(version, latestUpdate.version) > 0) {
          latestUpdate = update;
        }
      }
    }
    
    if (latestUpdate) {
      console.log(`Update available: ${latestUpdate.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: latestUpdate
      });
    } else {
      console.log('No updates available');
      res.json({
        hasUpdate: false,
        message: 'No updates available'
      });
    }
  } catch (error) {
    console.error('Error checking for updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Check for Strip Club specific updates
app.post('/v1/updates/strip-club', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, feature } = req.body;
    
    console.log(`Strip Club update check from ${deviceId} - feature: ${feature}`);
    
    // Check if there's a Strip Club specific update
    const stripClubUpdate = updates['1.1.0']; // Use the latest update for Strip Club features
    
    if (stripClubUpdate && compareVersions(stripClubUpdate.version, currentVersion) > 0) {
      // Add Strip Club specific features
      const enhancedUpdate = {
        ...stripClubUpdate,
        features: [
          ...stripClubUpdate.features,
          'Enhanced adult content filtering',
          'Improved age verification',
          'New nightlife features',
          'Advanced privacy controls'
        ],
        changelog: [
          ...stripClubUpdate.changelog,
          '🔥 Strip Club 18+ enhanced features',
          '🔞 Improved adult content management',
          '🎭 New nightlife entertainment features'
        ]
      };
      
      console.log(`Strip Club update available: ${enhancedUpdate.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: enhancedUpdate
      });
    } else {
      console.log('No Strip Club updates available');
      res.json({
        hasUpdate: false,
        message: 'No Strip Club updates available'
      });
    }
  } catch (error) {
    console.error('Error checking Strip Club updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Check for Gen 2 specific updates
app.post('/v1/updates/gen2', (req, res) => {
  try {
    const { currentVersion, platform, deviceId, feature } = req.body;
    
    console.log(`Gen 2 update check from ${deviceId} - feature: ${feature}`);
    
    // Check if there's a Gen 2 update available
    const gen2Update = updates['2.0.0'];
    
    if (gen2Update && compareVersions(gen2Update.version, currentVersion) > 0) {
      console.log(`Gen 2 update available: ${gen2Update.version}`);
      res.json({
        hasUpdate: true,
        updateInfo: gen2Update
      });
    } else {
      console.log('No Gen 2 updates available');
      res.json({
        hasUpdate: false,
        message: 'No Gen 2 updates available'
      });
    }
  } catch (error) {
    console.error('Error checking Gen 2 updates:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Report update status
app.post('/v1/updates/report', (req, res) => {
  try {
    const { updateId, status, error, deviceId, timestamp } = req.body;
    
    console.log(`Update status report from ${deviceId}: ${updateId} - ${status}`);
    
    // Store update history
    if (!updateHistory.has(deviceId)) {
      updateHistory.set(deviceId, []);
    }
    
    updateHistory.get(deviceId).push({
      updateId,
      status,
      error,
      timestamp,
      deviceId
    });
    
    res.json({
      success: true,
      message: 'Status reported successfully'
    });
  } catch (error) {
    console.error('Error reporting update status:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Get update history
app.get('/v1/updates/history', (req, res) => {
  try {
    const { deviceId } = req.query;
    
    if (deviceId && updateHistory.has(deviceId)) {
      res.json({
        updates: updateHistory.get(deviceId)
      });
    } else {
      res.json({
        updates: []
      });
    }
  } catch (error) {
    console.error('Error fetching update history:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Simulate update download
app.get('/v1/updates/download/:version', (req, res) => {
  try {
    const { version } = req.params;
    const update = updates[version];
    
    if (!update) {
      return res.status(404).json({
        error: 'Update not found',
        message: `Update version ${version} not found`
      });
    }
    
    console.log(`Download request for version ${version}`);
    
    // Simulate download by sending update info
    res.json({
      downloadUrl: update.downloadUrl,
      size: update.downloadSize,
      checksum: update.checksum
    });
  } catch (error) {
    console.error('Error handling download request:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Landing page for Luma Gen 2
app.get('/', (req, res) => {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luma Gen 2 - The Future of Social Gaming</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .hero {
            text-align: center;
            padding: 80px 20px;
        }
        
        .hero h1 {
            font-size: 4rem;
            font-weight: bold;
            margin-bottom: 20px;
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero .subtitle {
            font-size: 1.5rem;
            margin-bottom: 40px;
            opacity: 0.9;
        }
        
        .launch-date {
            font-size: 2rem;
            font-weight: bold;
            color: #FF6B6B;
            margin-bottom: 40px;
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 60px 0;
        }
        
        .feature {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .feature h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #FFD700;
        }
        
        .timeline {
            margin: 60px 0;
            text-align: center;
        }
        
        .timeline h2 {
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: #FFD700;
        }
        
        .timeline-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .timeline-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 25px;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .timeline-item .date {
            font-size: 1.2rem;
            font-weight: bold;
            color: #FF6B6B;
            margin-bottom: 10px;
        }
        
        .timeline-item .title {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .preregister-btn {
            display: inline-block;
            background: linear-gradient(45deg, #FF6B6B, #FF8E53);
            color: white;
            padding: 20px 40px;
            border-radius: 50px;
            text-decoration: none;
            font-size: 1.2rem;
            font-weight: bold;
            margin: 20px 10px;
            transition: transform 0.3s ease;
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.3);
        }
        
        .preregister-btn:hover {
            transform: translateY(-3px);
        }
        
        .stats {
            text-align: center;
            margin: 40px 0;
            font-size: 1.2rem;
        }
        
        .stats .number {
            font-size: 2rem;
            font-weight: bold;
            color: #FFD700;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .hero .subtitle {
                font-size: 1.2rem;
            }
            
            .launch-date {
                font-size: 1.5rem;
            }
            
            .features {
                grid-template-columns: 1fr;
            }
            
            .timeline-items {
                grid-template-columns: 1fr;
            }
        }
        
        .floating {
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="hero">
            <h1 class="floating">🚀 Luma Gen 2</h1>
            <p class="subtitle">The Future of Social Gaming</p>
            <div class="launch-date">Coming 2025</div>
            
            <div class="stats">
                <span class="number">15,420+</span> people have pre-registered
            </div>
            
            <a href="#preregister" class="preregister-btn">Pre-register Now</a>
        </div>
        
        <div class="features">
            <div class="feature">
                <h3>🎮 Luma Game Engine</h3>
                <p>Full 3D gaming platform with real-time physics and AI-powered game development</p>
            </div>
            <div class="feature">
                <h3>🌐 Metaverse Integration</h3>
                <p>Virtual worlds with 3D avatars and interactive experiences</p>
            </div>
            <div class="feature">
                <h3>🎯 Gen 2 AI</h3>
                <p>Advanced AI with reasoning, creativity, and real-time learning</p>
            </div>
            <div class="feature">
                <h3>🎨 3D Content Creation</h3>
                <p>Professional 3D modeling, animation, and real-time editing tools</p>
            </div>
            <div class="feature">
                <h3>🎲 Gaming Platform</h3>
                <p>Built-in game marketplace with multiplayer experiences</p>
            </div>
            <div class="feature">
                <h3>🎪 Virtual Events</h3>
                <p>Interactive live events, concerts, and virtual experiences</p>
            </div>
        </div>
        
        <div class="timeline">
            <h2>📅 2025 Release Timeline</h2>
            <div class="timeline-items">
                <div class="timeline-item">
                    <div class="date">Q1 2025</div>
                    <div class="title">Pre-registration Opens</div>
                    <p>Sign up for early access and exclusive updates</p>
                </div>
                <div class="timeline-item">
                    <div class="date">Q2 2025</div>
                    <div class="title">Closed Beta</div>
                    <p>Limited beta testing with select pre-registered users</p>
                </div>
                <div class="timeline-item">
                    <div class="date">Q3 2025</div>
                    <div class="title">Open Beta</div>
                    <p>Public beta with full feature set for all pre-registered users</p>
                </div>
                <div class="timeline-item">
                    <div class="date">Q4 2025</div>
                    <div class="title">Official Launch</div>
                    <p>Full Gen 2 release with all features available to everyone</p>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin: 60px 0;">
            <h2 style="color: #FFD700; margin-bottom: 30px;">🎁 Pre-registration Benefits</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 30px;">
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #FFD700;">⭐ Early Access</h3>
                    <p>Be among the first to experience Gen 2</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #FF6B6B;">🎁 Exclusive Rewards</h3>
                    <p>Get special in-game items and bonuses</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #4ECDC4;">📢 Priority Updates</h3>
                    <p>Receive updates and news first</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #9C27B0;">👥 Founder Status</h3>
                    <p>Special recognition as an early supporter</p>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin: 60px 0;">
            <h2 style="color: #FFD700; margin-bottom: 30px;">💻 System Requirements</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; margin-top: 30px;">
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #4ECDC4;">RAM</h3>
                    <p style="font-size: 1.2rem; font-weight: bold;">8GB+</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #FF9800;">Storage</h3>
                    <p style="font-size: 1.2rem; font-weight: bold;">50GB+</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #9C27B0;">GPU</h3>
                    <p style="font-size: 1.2rem; font-weight: bold;">Metal/Vulkan</p>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 15px;">
                    <h3 style="color: #00C853;">Network</h3>
                    <p style="font-size: 1.2rem; font-weight: bold;">5G/WiFi 6</p>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin: 60px 0;">
            <a href="#preregister" class="preregister-btn">🚀 Pre-register for Luma Gen 2</a>
        </div>
    </div>
</body>
</html>
  `;
  
  res.setHeader('Content-Type', 'text/html');
  res.send(html);
});

// Pre-registration API endpoints
app.get('/api/preregistration/stats', (req, res) => {
  try {
    // Update stats based on actual registrations
    const totalRegistrations = preRegistrations.length + stats.totalRegistrations;
    const earlyAccessCount = preRegistrations.filter(reg => {
      const regDate = new Date(reg.timestamp);
      const earlyAccessCutoff = new Date('2025-01-01');
      return regDate < earlyAccessCutoff;
    }).length;
    
    const betaAccessCount = preRegistrations.filter(reg => {
      const regDate = new Date(reg.timestamp);
      const betaAccessCutoff = new Date('2025-03-01');
      return regDate < betaAccessCutoff;
    }).length;

    const updatedStats = {
      totalRegistrations,
      earlyAccessCount,
      betaAccessCount,
      lastUpdated: new Date().toISOString()
    };

    res.json(updatedStats);
  } catch (error) {
    console.error('Error getting pre-registration stats:', error);
    res.status(500).json({ error: 'Failed to get statistics' });
  }
});

app.post('/api/preregistration/register', (req, res) => {
  try {
    const { email, deviceId, platform, timestamp, preferences } = req.body;

    // Validate required fields
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: 'Valid email is required' });
    }

    // Check if already registered
    const existingRegistration = preRegistrations.find(
      reg => reg.email.toLowerCase() === email.toLowerCase()
    );

    if (existingRegistration) {
      return res.status(409).json({ 
        error: 'Email already registered',
        registration: existingRegistration
      });
    }

    // Create new registration
    const newRegistration = {
      email: email.toLowerCase().trim(),
      deviceId: deviceId || `device-${Date.now()}`,
      platform: platform || 'unknown',
      timestamp: timestamp || new Date().toISOString(),
      preferences: {
        earlyAccess: true,
        betaTesting: true,
        marketingEmails: true,
        notifications: true,
        ...preferences
      },
      status: 'confirmed',
      registrationId: `reg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };

    // Add to storage
    preRegistrations.push(newRegistration);

    // Update stats
    stats.totalRegistrations = preRegistrations.length + 15420; // Base number
    stats.lastUpdated = new Date().toISOString();

    console.log(`New pre-registration: ${email} (${newRegistration.registrationId})`);

    res.status(201).json({
      success: true,
      message: 'Pre-registration successful',
      registration: newRegistration,
      stats: {
        totalRegistrations: stats.totalRegistrations,
        earlyAccessCount: preRegistrations.filter(reg => {
          const regDate = new Date(reg.timestamp);
          const earlyAccessCutoff = new Date('2025-01-01');
          return regDate < earlyAccessCutoff;
        }).length,
        betaAccessCount: preRegistrations.filter(reg => {
          const regDate = new Date(reg.timestamp);
          const betaAccessCutoff = new Date('2025-03-01');
          return regDate < betaAccessCutoff;
        }).length
      }
    });

  } catch (error) {
    console.error('Error processing pre-registration:', error);
    res.status(500).json({ error: 'Failed to process pre-registration' });
  }
});

app.get('/api/preregistration/check/:email', (req, res) => {
  try {
    const { email } = req.params;
    const registration = preRegistrations.find(
      reg => reg.email.toLowerCase() === email.toLowerCase()
    );

    if (registration) {
      res.json({
        isRegistered: true,
        registration: {
          email: registration.email,
          timestamp: registration.timestamp,
          status: registration.status,
          preferences: registration.preferences
        }
      });
    } else {
      res.json({
        isRegistered: false
      });
    }
  } catch (error) {
    console.error('Error checking registration status:', error);
    res.status(500).json({ error: 'Failed to check registration status' });
  }
});

app.put('/api/preregistration/preferences', (req, res) => {
  try {
    const { email, preferences } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const registration = preRegistrations.find(
      reg => reg.email.toLowerCase() === email.toLowerCase()
    );

    if (!registration) {
      return res.status(404).json({ error: 'Registration not found' });
    }

    // Update preferences
    registration.preferences = {
      ...registration.preferences,
      ...preferences
    };

    res.json({
      success: true,
      message: 'Preferences updated successfully',
      registration: {
        email: registration.email,
        preferences: registration.preferences,
        timestamp: registration.timestamp,
        status: registration.status
      }
    });

  } catch (error) {
    console.error('Error updating preferences:', error);
    res.status(500).json({ error: 'Failed to update preferences' });
  }
});

// Health check
app.get('/v1/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    updates: Object.keys(updates)
  });
});

// For Vercel deployment
if (process.env.VERCEL) {
  // Export for Vercel serverless functions
  module.exports = app;
} else {
  // Local development
  app.listen(PORT, () => {
    console.log(`🚀 Luma Update Server running on port ${PORT}`);
    console.log(`📱 Available updates: ${Object.keys(updates).join(', ')}`);
    console.log(`🔗 Health check: http://localhost:${PORT}/v1/health`);
  });
} 